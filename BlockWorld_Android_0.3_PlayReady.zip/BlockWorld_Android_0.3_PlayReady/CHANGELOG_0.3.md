# BlockWorld 0.3 – Admin Gratis

- Nur der Platform-Admin bekommt bezahlte Avatar-Items gratis.
- Nur der Platform-Admin bekommt Gamepasses gratis.
- Creator ULTRA PRO MAX bleibt für den Admin kostenlos.
- Nicht-Admins zahlen weiterhin die normalen BlockBux-Preise.
- Admin-Käufe erzeugen keine 70/30-Einnahmen, weil kein BlockBux abgezogen wird.
- Vorbereitung für Privatserver: Admin-Preis = 0, andere Spieler = Creator-Preis zwischen 0 und 30 BlockBux/Monat.
- Paket-ID bleibt unverändert, damit die App als Update weitergeführt werden kann.

Hinweis: Die Admin-Prüfung ist in dieser Offline-Beta noch clientseitig. Vor echtem Online-Betrieb muss die Admin-Rolle serverseitig geprüft werden.
