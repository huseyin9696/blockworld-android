# BlockWorld Android RC 0.2

Release-Candidate-Paket für BlockWorld.

## Enthalten
- aktuelles BlockWorld-Spiel
- Android-App-Wrapper
- `compileSdk 36` / `targetSdk 36`
- sichere WebViewAssetLoader-Origin
- AndroidX WebKit
- Native Bridge für App-Version/Haptic
- GitHub Actions Cloud-Build
- Backend-Migrationsentwurf mit RLS
- Purchase-Verifikations-Edge-Function (fail-closed)
- Store/Privacy/Release-Dokumente

## Cloud Build
`.github/workflows/android-build.yml` baut:
- installierbare Debug-APK
- Release-AAB (noch ohne endgültigen Publisher-Upload-Key)

## Sicherheitsgrenze
Clientseitige BlockBux, Käufe und Owner-Rollen aus der HTML-Beta sind
weiterhin nur Demo. Vor öffentlichem Release werden diese Werte auf das
Backend umgestellt.

## Keine Geheimnisse enthalten
Dieses ZIP enthält absichtlich weder Play-Service-Account-Schlüssel noch
App-Signing-Key noch echte Zahlungsdaten.
