# Google-Play-Release-Checkliste

## Alpha
- [x] Android-Projekt mit eingebettetem Spiel
- [x] Offline-Startseite / Spiel-Assets
- [x] Vollbild-Android-Hülle
- [x] Internet nur für spätere Backend-Nutzung erlaubt
- [ ] Auf echten Android-Geräten testen
- [ ] Abstürze und Layoutfehler beheben

## Produktions-Backend
- [ ] Eigenes Supabase-/Backend-Projekt für BlockWorld
- [ ] Authentifizierung
- [ ] globale eindeutige Usernames
- [ ] Owner-Rolle über feste User-ID
- [ ] Wallet serverseitig
- [ ] Avatar-Inventar serverseitig
- [ ] Freunde / Blockieren / Melden serverseitig
- [ ] Creator-Spiele serverseitig
- [ ] RLS / Berechtigungen / Rate Limits

## Käufe
- [ ] Google Play Console des erwachsenen Publishers
- [ ] ULTRA PRO MAX Monatsabo anlegen
- [ ] BlockBux-Produkte anlegen
- [ ] Google Play Billing anbinden
- [ ] Kaufbelege serverseitig prüfen
- [ ] Rückerstattungen / Kündigungen behandeln
- [ ] Keine Client-seitige Guthaben-Manipulation

## Sicherheit
- [ ] Chat serverseitig moderieren
- [ ] Melde-/Blockier-System
- [ ] Alters-/Elternregeln prüfen
- [ ] Voice nur nach passender Freigabe
- [ ] Datenschutzangaben vervollständigen

## Store
- [ ] endgültiger App-Name
- [ ] App-Icon
- [ ] Feature Graphic
- [ ] Screenshots
- [ ] Kurzbeschreibung
- [ ] Langbeschreibung
- [ ] Datenschutzerklärung veröffentlichen
- [ ] Inhaltsbewertung
- [ ] Datensicherheitsformular
- [ ] Zielgruppe korrekt angeben
- [ ] interner/geschlossener Test
- [ ] AAB signieren und hochladen
