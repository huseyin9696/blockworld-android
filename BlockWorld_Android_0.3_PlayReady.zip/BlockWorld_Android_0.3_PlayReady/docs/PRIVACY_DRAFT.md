# BlockWorld – Datenschutzentwurf

Status: ENTWURF, nicht veröffentlichungsfertig.

Die aktuelle Alpha speichert Spielstände lokal auf dem Gerät.
Eine spätere Online-Version kann Kontodaten, Avatar-Inventar, erstellte Spiele,
Käufe, Freundschaften, Moderationsmeldungen und Sicherheits-Einstellungen verarbeiten.

Für eine öffentliche Veröffentlichung müssen insbesondere ergänzt werden:
- verantwortlicher Publisher / Kontakt
- genaue Serveranbieter und Speicherorte
- Speicherdauer
- Lösch- und Auskunftswege
- Daten von Minderjährigen / Elternfunktionen
- Google-Play-Abrechnung
- Mikrofon-/Voice-Nutzung, falls aktiviert
- Analyse-/Crash-Dienste, falls später eingebaut

Diese Datei ist eine technische Vorlage und keine Rechtsberatung.
