# BlockWorld – Store-Entwurf

**Name:** BlockWorld

**Kurzbeschreibung:**
Baue deinen Avatar, meistere Obbys und erschaffe eigene Blockwelten.

**Lange Beschreibung – Entwurf:**
BlockWorld ist ein kreatives 3D-Spiel mit Parkour-Welten, Avatar-Anpassung,
Quests und einem integrierten Creator-Studio. Spiele Herausforderungen,
gestalte deinen Avatar und baue eigene Strecken mit unterschiedlichen
Themen, Checkpoints und Hindernissen.

Hinweis: Vor Veröffentlichung müssen Funktionsumfang, Altersangaben,
Datenschutz und Zahlungsfunktionen mit der tatsächlichen Release-Version
übereinstimmen.
