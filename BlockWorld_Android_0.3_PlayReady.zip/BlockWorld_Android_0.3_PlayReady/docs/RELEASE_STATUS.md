# BlockWorld Release Candidate 0.2

## Fertig vorbereitet
- Android-Projekt
- eingebettetes aktuelles Spiel
- Android-16/API-36-Ziel
- sichere HTTPS-AppAssets-WebView
- JavaScript + localStorage
- Vollbild / Landscape / Haptic-Bridge
- WebView-Crash-Recovery
- GitHub-Cloud-Build für Debug-APK + Release-AAB
- Backend-Tabellen
- Row Level Security
- eindeutige Usernames auf Datenbankebene
- servergeschützte Wallet/Inventar/Entitlements
- Friends/Reports/Games-Schema
- Google-Play-Produkt-IDs als Vorlage
- Kaufprüfungs-Edge-Function mit sicherem FAIL-CLOSED-Verhalten
- Datenschutz-/Store-/Release-Vorlagen

## Noch extern erforderlich
1. Ein eigenes BlockWorld-Supabase-Projekt auswählen/anlegen.
2. Ein erwachsener Publisher richtet Google Play Console ein.
3. Google-Play-Produkte und Service-Account-Zugang werden dort erstellt.
4. Erst dann wird die echte Kaufprüfung aktiviert und getestet.
5. Geschlossener Test + Store-Prüfung.

Keine echte Zahlung wird vor diesen Schritten freigeschaltet.
