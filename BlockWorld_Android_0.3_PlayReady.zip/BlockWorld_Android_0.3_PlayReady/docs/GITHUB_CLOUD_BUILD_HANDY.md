# APK über GitHub bauen – auch ohne eigenen PC

Das Projekt enthält `.github/workflows/android-build.yml`.

Sobald der komplette Projektordner in einem GitHub-Repository liegt:
1. GitHub öffnet automatisch den Bereich **Actions**.
2. Workflow **Build BlockWorld Android** starten.
3. Der Cloud-Rechner baut die App.
4. Unter **Artifacts** erscheint `BlockWorld-Android-Debug-APK`.
5. Diese Debug-APK ist nur für Tests.

Zusätzlich wird ein Release-AAB gebaut. Ohne geschützten Upload-Key ist es
absichtlich nicht die endgültig signierte Play-Store-Datei.

Für die endgültige Store-Signatur muss der erwachsene Publisher den
Upload-Key sicher verwalten.
