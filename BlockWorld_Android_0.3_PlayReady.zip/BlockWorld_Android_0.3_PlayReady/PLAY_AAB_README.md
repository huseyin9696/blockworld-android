# BlockWorld 0.3 – Google Play AAB

Dieses Projekt ist für einen Google-Play-Release vorbereitet.

## Bereits erledigt
- applicationId: `com.blockworld.game`
- targetSdk / compileSdk: 36
- versionCode: 3
- versionName: 0.3.0
- BuildConfig korrekt aktiviert
- Release-Signing liest Geheimnisse nur aus Umgebungsvariablen
- keine echten Signing-Passwörter im Projekt

## Für einen signierten Play-Build benötigt
Ein dauerhafter Upload-Schlüssel (`.jks`) und vier GitHub-Secrets:

- `BLOCKWORLD_UPLOAD_KEYSTORE_B64`
- `BLOCKWORLD_STORE_PASSWORD`
- `BLOCKWORLD_KEY_ALIAS`
- `BLOCKWORLD_KEY_PASSWORD`

Der Upload-Schlüssel muss sicher aufbewahrt werden. Er sollte nicht im öffentlichen Repository liegen.
Ein erwachsener Publisher sollte den Schlüssel und das Google-Play-Console-Konto verwalten.

## Build-Ausgabe
Nach erfolgreichem Workflow entsteht:
`app/build/outputs/bundle/release/app-release.aab`
