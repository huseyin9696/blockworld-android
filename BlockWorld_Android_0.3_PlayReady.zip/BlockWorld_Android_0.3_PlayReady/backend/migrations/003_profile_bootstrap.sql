-- Creates a profile and wallet when a new auth user is created.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_name text;
  canonical text;
begin
  requested_name := coalesce(new.raw_user_meta_data->>'username', 'Player');
  requested_name := left(trim(requested_name), 24);
  canonical := lower(regexp_replace(requested_name, '\s+', ' ', 'g'));

  insert into public.profiles(id, username, username_key)
  values(new.id, requested_name, canonical);

  insert into public.wallets(user_id)
  values(new.id);

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
