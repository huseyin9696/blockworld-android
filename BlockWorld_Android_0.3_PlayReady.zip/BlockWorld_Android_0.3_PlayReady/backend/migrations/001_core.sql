-- BlockWorld backend core
-- Run only in a dedicated BlockWorld Supabase project.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  username_key text not null unique,
  role text not null default 'player'
    check (role in ('player','moderator','owner')),
  created_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  blockbux bigint not null default 0 check (blockbux >= 0),
  mini_blockbux integer not null default 0
    check (mini_blockbux between 0 and 99),
  updated_at timestamptz not null default now()
);

create table if not exists public.avatar_inventory (
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_id text not null,
  acquired_at timestamptz not null default now(),
  primary key (user_id, item_id)
);

create table if not exists public.entitlements (
  user_id uuid not null references public.profiles(id) on delete cascade,
  entitlement_id text not null,
  source text not null check (source in ('play','admin','promo')),
  active boolean not null default true,
  expires_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, entitlement_id)
);

create table if not exists public.created_games (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 40),
  data jsonb not null,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.friendships (
  user_id uuid not null references public.profiles(id) on delete cascade,
  friend_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending'
    check (status in ('pending','accepted','blocked')),
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id),
  check (user_id <> friend_id)
);

create table if not exists public.reports (
  id bigint generated always as identity primary key,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_user_id uuid references public.profiles(id) on delete set null,
  target_game_id uuid references public.created_games(id) on delete set null,
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open'
    check (status in ('open','reviewing','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.purchase_events (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id text not null,
  purchase_token_hash text not null unique,
  state text not null check (state in ('verified','revoked','refunded')),
  payload jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
