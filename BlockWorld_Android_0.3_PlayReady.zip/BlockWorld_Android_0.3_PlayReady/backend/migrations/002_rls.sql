-- RLS: users can read their own sensitive data.
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.avatar_inventory enable row level security;
alter table public.entitlements enable row level security;
alter table public.created_games enable row level security;
alter table public.friendships enable row level security;
alter table public.reports enable row level security;
alter table public.purchase_events enable row level security;

create policy "profiles readable by authenticated users"
  on public.profiles for select to authenticated
  using (true);

create policy "users update own profile"
  on public.profiles for update to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id and role = 'player');

create policy "users read own wallet"
  on public.wallets for select to authenticated
  using (auth.uid() = user_id);

create policy "users read own inventory"
  on public.avatar_inventory for select to authenticated
  using (auth.uid() = user_id);

create policy "users read own entitlements"
  on public.entitlements for select to authenticated
  using (auth.uid() = user_id);

create policy "published games are readable"
  on public.created_games for select to authenticated
  using (published or creator_id = auth.uid());

create policy "users create own games"
  on public.created_games for insert to authenticated
  with check (creator_id = auth.uid());

create policy "users update own games"
  on public.created_games for update to authenticated
  using (creator_id = auth.uid())
  with check (creator_id = auth.uid());

create policy "users delete own games"
  on public.created_games for delete to authenticated
  using (creator_id = auth.uid());

create policy "users read own friendship rows"
  on public.friendships for select to authenticated
  using (user_id = auth.uid() or friend_id = auth.uid());

create policy "users create own friendship rows"
  on public.friendships for insert to authenticated
  with check (user_id = auth.uid());

create policy "users update involved friendship rows"
  on public.friendships for update to authenticated
  using (user_id = auth.uid() or friend_id = auth.uid());

create policy "users submit reports"
  on public.reports for insert to authenticated
  with check (reporter_id = auth.uid());

create policy "users read own submitted reports"
  on public.reports for select to authenticated
  using (reporter_id = auth.uid());

-- No client insert/update/delete policy is intentionally provided for:
-- wallets, avatar_inventory, entitlements, purchase_events.
-- Those must be changed by trusted backend/service-role code only.
