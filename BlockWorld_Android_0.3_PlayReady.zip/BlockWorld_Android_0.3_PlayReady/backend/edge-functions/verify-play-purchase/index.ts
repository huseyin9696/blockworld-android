import "jsr:@supabase/functions-js/edge-runtime.d.ts";

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const configured =
    !!Deno.env.get("GOOGLE_PLAY_PACKAGE_NAME") &&
    !!Deno.env.get("GOOGLE_PLAY_SERVICE_ACCOUNT_JSON");

  if (!configured) {
    return Response.json(
      {
        ok: false,
        code: "PLAY_NOT_CONFIGURED",
        message:
          "Google Play verification is intentionally disabled until the adult publisher account and server credentials are configured."
      },
      { status: 503 }
    );
  }

  // Production implementation point:
  // 1. Read the authenticated Supabase user from the JWT.
  // 2. Validate productId + purchaseToken with Google Play Developer API.
  // 3. Store a hash of the purchase token to prevent replay.
  // 4. Grant only the verified BlockBux/entitlement server-side.
  // 5. Never trust amount, price or entitlement sent by the client.

  return Response.json(
    {
      ok: false,
      code: "VERIFICATION_IMPLEMENTATION_REQUIRED"
    },
    { status: 501 }
  );
});
