# BlockWorld Alpha
# Add release-specific ProGuard rules here later.
